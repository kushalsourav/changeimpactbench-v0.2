"""FastAPI integration for ChangeImpactBench."""
